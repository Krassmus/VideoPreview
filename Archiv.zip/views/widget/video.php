<video src="<?= htmlReady($url) ?>" id="previewvideo" controls></video>

